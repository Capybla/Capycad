import sys
import numpy as np
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QPushButton, QWidget,
    QHBoxLayout, QFileDialog, QLabel, QDialog, QDialogButtonBox, QInputDialog
)
from PyQt5.QtOpenGL import QGLWidget
from OpenGL.GL import *
from OpenGL.GLU import *
from stl import mesh
import random  # Esto se reemplazará con la integración real de DeepSDF
import os
import subprocess

class GLWidget(QGLWidget):
    def __init__(self, parent=None):
        super(GLWidget, self).__init__(parent)
        self.objects = []
        self.history = []
        self.selected_object = None
        self.is_solid = True

    def initializeGL(self):
        glClearColor(0.2, 0.2, 0.2, 1.0)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)

    def paintGL(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
        gluLookAt(0, 0, 20, 0, 0, 0, 0, 1, 0)

        # Renderizar la cuadrícula de construcción
        self.render_grid()

        # Renderizar todos los objetos
        for obj in self.objects:
            obj.render()

    def render_grid(self):
        glColor3f(0.5, 0.5, 0.5)
        glBegin(GL_LINES)
        grid_size = 10
        for i in range(-grid_size, grid_size + 1):
            glVertex3f(i, -grid_size, 0)
            glVertex3f(i, grid_size, 0)
            glVertex3f(-grid_size, i, 0)
            glVertex3f(grid_size, i, 0)
        glEnd()

    def add_cube(self, bevel=0):
        cube = Cube(bevel=bevel)
        self.objects.append(cube)
        self.history.append(('add', cube))
        self.update()

    def add_sphere(self, resolution=20):
        sphere = Sphere(resolution=resolution)
        self.objects.append(sphere)
        self.history.append(('add', sphere))
        self.update()

    def add_cylinder(self, resolution=20, bevel=0):
        cylinder = Cylinder(resolution=resolution, bevel=bevel)
        self.objects.append(cylinder)
        self.history.append(('add', cylinder))
        self.update()

    def add_custom_shape(self, description):
        custom_shape = self.generate_3d_model_from_text(description)
        if custom_shape:
            self.objects.append(custom_shape)
            self.history.append(('add', custom_shape))
            self.update()

    def generate_3d_model_from_text(self, description):
        latent_code = self.text_to_latent_code(description)
        stl_filename = self.generate_stl_from_latent(latent_code)
        
        if stl_filename:
            model_mesh = mesh.Mesh.from_file(stl_filename)
            generated_object = ImportedSTLObject(model_mesh)
            return generated_object
        return None

    def text_to_latent_code(self, description):
        # Convertir descripción en código latente usando un modelo entrenado de texto a latente.
        latent_code = self.get_latent_from_text_model(description)
        return latent_code

    def generate_stl_from_latent(self, latent_code):
        # Llama a DeepSDF para generar el STL a partir del código latente.
        sdf_command = f"python generate_sdf.py --latent {latent_code} --output generated_model.stl"
        
        # Ejecuta el comando
        process = subprocess.Popen(sdf_command, shell=True, cwd="DeepSDF-main/")
        process.wait()
        
        # Verifica si el archivo STL fue generado
        stl_filename = "DeepSDF-main/generated_model.stl"
        if os.path.exists(stl_filename):
            return stl_filename
        return None

    def import_stl(self):
        options = QFileDialog.Options()
        filename, _ = QFileDialog.getOpenFileName(self, "Importar STL", "", "STL Files (*.stl);;All Files (*)", options=options)
        if filename:
            model_mesh = mesh.Mesh.from_file(filename)
            imported_object = ImportedSTLObject(model_mesh)
            self.objects.append(imported_object)
            self.history.append(('import', imported_object))
            self.update()

    def undo_action(self):
        if self.history:
            action, obj = self.history.pop()
            if action == 'add':
                self.objects.remove(obj)
            elif action == 'import':
                self.objects.remove(obj)
            self.update()

    def save_scene(self):
        options = QFileDialog.Options()
        filename, _ = QFileDialog.getSaveFileName(self, "Guardar Escena", "", "STL Files (*.stl);;All Files (*)", options=options)
        if filename:
            combined_mesh = None
            for obj in self.objects:
                if combined_mesh is None:
                    combined_mesh = obj.model_mesh
                else:
                    combined_mesh = mesh.Mesh(np.concatenate([combined_mesh.data, obj.model_mesh.data]))

            if combined_mesh:
                combined_mesh.save(filename)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Capycad")
        self.setGeometry(100, 100, 800, 600)
        self.glWidget = GLWidget(self)
        self.setCentralWidget(self.glWidget)
        self.initUI()

    def initUI(self):
        self.glWidget.setFocusPolicy(Qt.StrongFocus)

        self.menu = self.menuBar().addMenu("Archivo")
        import_action = self.menu.addAction("Importar STL")
        import_action.triggered.connect(self.glWidget.import_stl)

        save_action = self.menu.addAction("Guardar Escena")
        save_action.triggered.connect(self.glWidget.save_scene)

        undo_action = self.menu.addAction("Deshacer")
        undo_action.triggered.connect(self.glWidget.undo_action)

        generate_action = self.menu.addAction("Generar Objeto por IA")
        generate_action.triggered.connect(self.generate_object_by_ia)

    def generate_object_by_ia(self):
        description, ok = QInputDialog.getText(self, "Generar Objeto por IA", "Describe el objeto que deseas generar:")
        if ok and description:
            dialog = PreviewDialog(self.glWidget, description)
            if dialog.exec_():
                preview_object = dialog.get_preview_object()
                if preview_object:
                    self.glWidget.objects.append(preview_object)
                    self.glWidget.history.append(('add', preview_object))
                    self.glWidget.update()


class PreviewDialog(QDialog):
    def __init__(self, glWidget, description):
        super().__init__()
        self.glWidget = glWidget
        self.description = description
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Previsualización del Objeto")
        self.setGeometry(150, 150, 400, 300)

        self.layout = QVBoxLayout(self)
        self.label = QLabel("Generando previsualización...")
        self.layout.addWidget(self.label)

        self.preview_object = self.glWidget.generate_3d_model_from_text(self.description)
        if self.preview_object:
            self.label.setText("Previsualización generada. ¿Deseas confirmar?")
        else:
            self.label.setText("Error al generar previsualización.")

        self.confirm_button = QPushButton("Confirmar", self)
        self.confirm_button.clicked.connect(self.accept)
        self.layout.addWidget(self.confirm_button)

        self.cancel_button = QPushButton("Cancelar", self)
        self.cancel_button.clicked.connect(self.reject)
        self.layout.addWidget(self.cancel_button)

    def get_preview_object(self):
        return self.preview_object


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mainWindow = MainWindow()
    mainWindow.show()
    sys.exit(app.exec_())
