# test_torch.py
import torch
print("PyTorch version:", torch.__version__)
